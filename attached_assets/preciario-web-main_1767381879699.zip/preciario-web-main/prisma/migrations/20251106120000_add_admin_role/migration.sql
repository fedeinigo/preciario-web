-- Add admin role to Role enum
ALTER TYPE "Role" ADD VALUE 'admin';
