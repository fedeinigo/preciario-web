import { createDomEnvironment } from "../mocks/simple-dom";

createDomEnvironment();
