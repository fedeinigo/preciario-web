export interface DeepRecord {
  [key: string]: string | DeepRecord;
}
