export { default } from "@/app/portal/directo/configuraciones/user-management/page";
