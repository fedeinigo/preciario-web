import { redirect } from "next/navigation";

export default function LegacyDirectPortalConfigurationsPage() {
  redirect("/configuraciones");
}
