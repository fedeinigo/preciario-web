// src/app/direct-portal/page.tsx
import { redirect } from "next/navigation";

export default function LegacyDirectPortalPage() {
  redirect("/portal/directo");
}
