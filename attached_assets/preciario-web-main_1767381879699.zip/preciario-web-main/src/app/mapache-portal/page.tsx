import { redirect } from "next/navigation";

export default function MapachePortalPage() {
  redirect("/portal/mapache/generator");
}
