// src/app/portal/directo/page.tsx
import { redirect } from "next/navigation";

export default function DirectPortalEntryPage() {
  redirect("/portal/directo/generator");
}
