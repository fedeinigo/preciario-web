export { default } from "@/app/direct-portal/stats/page";
