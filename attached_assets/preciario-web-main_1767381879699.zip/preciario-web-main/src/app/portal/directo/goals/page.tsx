export { default } from "@/app/direct-portal/goals/page";
