export { default } from "@/app/direct-portal/configuraciones/page";
