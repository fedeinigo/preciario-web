// src/app/portal/directo/configuraciones/user-management/page.tsx
import { redirect } from "next/navigation";

export default function LegacyUserManagementPage() {
  redirect("/configuraciones/user-management");
}
