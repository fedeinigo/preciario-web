export { default } from "@/app/direct-portal/history/page";
