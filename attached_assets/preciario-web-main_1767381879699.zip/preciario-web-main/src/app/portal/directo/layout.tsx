// src/app/portal/directo/layout.tsx
export { default } from "@/app/direct-portal/layout";
