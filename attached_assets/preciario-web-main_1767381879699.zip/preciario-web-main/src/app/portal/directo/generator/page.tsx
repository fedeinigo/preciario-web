export { default } from "@/app/direct-portal/generator/page";
