export { default } from "@/app/marketing-portal/history/page";
