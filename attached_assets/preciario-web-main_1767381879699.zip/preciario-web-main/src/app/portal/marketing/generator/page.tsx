export { default } from "@/app/marketing-portal/generator/page";
