// src/app/portal/partner/page.tsx
import { redirect } from "next/navigation";

export default function PartnerPortalRedirect() {
  redirect("/partner-portal");
}
