// src/app/portal/mapache/page.tsx
import { redirect } from "next/navigation";

export default function MapachePortalRedirect() {
  redirect("/portal/mapache/generator");
}
