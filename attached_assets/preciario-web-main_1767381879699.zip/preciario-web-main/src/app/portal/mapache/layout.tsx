export { default } from "@/app/mapache-portal/layout";
