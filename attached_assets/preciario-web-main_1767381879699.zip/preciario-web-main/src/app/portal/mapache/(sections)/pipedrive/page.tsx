export { default } from "@/app/mapache-portal/(sections)/pipedrive/page";
