export { default } from "@/app/mapache-portal/(sections)/goals/page";
