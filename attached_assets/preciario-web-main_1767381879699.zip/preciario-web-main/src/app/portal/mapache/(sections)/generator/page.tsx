export { default } from "@/app/mapache-portal/(sections)/generator/page";
