import MarketingPortalClient from "@/app/marketing-portal/MarketingPortalClient";

export default function MarketingGeneratorPage() {
  return <MarketingPortalClient initialView="generator" />;
}
