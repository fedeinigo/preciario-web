// src/app/components/features/proposals/lib/types.ts
export type { UIItem, SaveProposalInput, ProposalRecord } from "@/lib/types";
