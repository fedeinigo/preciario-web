// src/types/next-auth.d.ts
import "next-auth";
import "next-auth/jwt";
import type { PortalAccessId } from "@/constants/portals";
import type { AppRole } from "@/constants/teams";

declare module "next-auth" {
  interface User {
    id: string;
    role?: AppRole;
    team?: string | null;
    positionName?: string | null;
    leaderEmail?: string | null;
  }

  interface Session {
    user: {
      id: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
      role: AppRole;
      team: string | null;
      portals?: PortalAccessId[];
      positionName: string | null;
      leaderEmail: string | null;
    };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string;
    role?: AppRole;
    team?: string | null;
    accessToken?: string | null;
    refreshToken?: string | null;
    accessTokenExpires?: number | null; // epoch ms
    portals?: PortalAccessId[];
    positionName?: string | null;
    leaderEmail?: string | null;
  }
}
